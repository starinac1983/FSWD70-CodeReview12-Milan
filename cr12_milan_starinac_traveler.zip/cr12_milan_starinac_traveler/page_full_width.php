<?php
/**
 * Template Name: Full Width Page
 *
 * This is the template that displays without sidebars.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Traveler
 */

get_header();
?>

	<div id="primary" class="content-area col-md-12">
		<?php if(have_posts()) :  ?>  <!--if there are any posts-->
            <?php while(have_posts()) : the_post(); ?><!--while there are posts, show the posts-->

          <section class="card mt-2 mb-2" style="">
  				  <div class="card-body">
				  	<?php if(has_post_thumbnail());?>
				  	<img class="img-fluid" src="<?php the_post_thumbnail_url('smallest');?>">
				  
				  	<p class="h5 mb-3 text-danger">Post title</p>
				    <p class="h3 mb-3"><?php the_title(); ?></p>
				    <p class="h5 mb-3 text-danger">Post content</p>
				    <p class="h3 mb-3"><?php the_content(); ?></p>
				    <p class="h5 mb-3 text-danger">Post time</p>
				    <p class="h5 mb-3"><?php the_time('F j, Y g:i a'); ?></p>
				    <p class="h5 mb-3 text-danger">Author</p>
				    <p class="h5 mb-3"><a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a></p>
				    <a href="<?php the_permalink(); ?>" class="btn btn-primary">See post</a>
				  </div>
			</section>
            <?php comments_template(); ?> <!--shows the comments, if there are any -->

          <?php endwhile; ?> <!--end the while loop-->

            <?php else : ?> <!--if there are no posts-->
              <p><?php__('No Posts Found'); ?></p>
          <?php endif; ?><!--endif-->
          </div><!-- /.blog-post -->
</div>

<?php get_footer();
